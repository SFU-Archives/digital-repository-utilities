# Contact Sheet

Command line script to convert a folder of image files into a labelled contact sheet pdf document. 

When prompted, enter the directory location of the folder of files to be processed.

The number of columns for contact sheet grid is defaulted to five. Edit script to change if needed.
